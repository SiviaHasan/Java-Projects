package com.jspider.product_management_application_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jspider.product_management_application_connection.DatabaseConnection;
import com.jspider.product_management_application_dto.Customer;
import com.jspider.product_management_application_dto.ProductOwner;

public class ProductOwnerDao {
     
	Connection connection=DatabaseConnection.getConnection();
    PreparedStatement ps;
    
    private final String PRODUCTOWNERLOGINQUERY="SELECT * from productowner";
    private final String PRODUCTOWNERREGISTERQUERY="insert into productowner(name,email,password,verified)values(?,?,?,'No')";
	
	
	public ProductOwner productOwnerRegistration(ProductOwner po)
	{
		try {
			ps=connection.prepareStatement(PRODUCTOWNERREGISTERQUERY);
			
			ps.setString(1, po.getName());
			ps.setString(2,po.getEmail());
			ps.setString(3,po.getPassword());
			
			ps.execute();
			
		return po;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
		
	}
	public ProductOwner[] productOwnerLogin()
	{
		try {
			ps=connection.prepareStatement(PRODUCTOWNERLOGINQUERY);
			
			 
            ResultSet resultSet=ps.executeQuery();
			
			ProductOwner[] a=new ProductOwner[10];
			int i=0;
			while(resultSet.next())
			{
	   
				String name=resultSet.getString("name");
				
				String email=resultSet.getString("email");

				String pass=resultSet.getString("password");
				
				String verified=resultSet.getString("verified");
				
				ProductOwner po=new ProductOwner(name,email, pass,verified);
				a[i]= po;
				i++;
			
			}
	      return a;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}	 
		
	}

}
