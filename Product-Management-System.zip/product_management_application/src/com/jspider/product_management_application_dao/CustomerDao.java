package com.jspider.product_management_application_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jspider.product_management_application_connection.DatabaseConnection;

import com.jspider.product_management_application_dto.Customer;

public class CustomerDao {
	 
    Connection connection=DatabaseConnection.getConnection();
    PreparedStatement ps;
    private final String CUSTOMERINSERTQUERY="insert into customer(name,email,password)values(?,?,?)";
    private final String CUSTOMERLOGINQUERY="select * from customer";
	
	
	public Customer customerRegistration(Customer customer)
	{
		try {
			ps=connection.prepareStatement(CUSTOMERINSERTQUERY);
			
			ps.setString(1, customer.getName());
			ps.setString(2,customer.getEmail());
			ps.setString(3,customer.getPassword());
			
			ps.execute();
			
		return customer;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
		
	}
	public Customer[] customerLogin()
	{
		try {
			ps=connection.prepareStatement(CUSTOMERLOGINQUERY);
			
			 
            ResultSet resultSet=ps.executeQuery();
			
			Customer[] a=new Customer[10];
			int i=0;
			while(resultSet.next())
			{
	
				String email=resultSet.getString("email");

				String pass=resultSet.getString("password");	
				
				Customer cd=new Customer(email, pass);
				a[i]= cd;
				i++;
			}
	      return a;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}	 
		
	}

}
