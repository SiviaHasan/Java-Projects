package com.jspider.product_management_application_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.jspider.product_management_application_connection.DatabaseConnection;
import com.jspider.product_management_application_dto.Admin;
import com.jspider.product_management_application_dto.Customer;
import com.jspider.product_management_application_dto.Product;
import com.jspider.product_management_application_dto.ProductOwner;


public class AdminDao {
	
	Connection connection= DatabaseConnection.getConnection();
	 PreparedStatement ps;
	 
	 private final String DISPLAYPRODUCTQUERY="SELECT * from product";
	 private final String DISPLAYCUSTOMERQUERY="SELECT * from customer";
	 private final String DISPLAYPRODUCTOWNERQUERY="SELECT * from productowner";
	 private final String DISPLAYADMINQUERY = "SELECT * from admin";
	 private final String VERIFYPRODUCTOWNER="UPDATE productowner set verified=? where email=?";
	 
	 
	 public Product[] displayAllProduct() {
		 try {
			ps=connection.prepareStatement(DISPLAYPRODUCTQUERY);
			
			ResultSet resultSet=ps.executeQuery();
			
			Product[] p=new Product[10];
			int i=0;
			while(resultSet.next())
			{
				int id=resultSet.getInt("id");
				
				String name=resultSet.getString("name");
				double price=resultSet.getDouble("price");
				String color=resultSet.getString("color");
				
				LocalDate md=resultSet.getDate("md").toLocalDate();
				LocalDate expd=resultSet.getDate("expd").toLocalDate();
				
				Product pro1=new Product(id, name, price, color, md, expd);
				p[i]=pro1;
				i++;
			}
	      return p;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
	 }	 
		 
		public ProductOwner[] displayAllProductOwner() {
			 try {
				ps=connection.prepareStatement(DISPLAYPRODUCTOWNERQUERY);
				
				ResultSet resultSet=ps.executeQuery();
				
				ProductOwner[] p=new ProductOwner[10];
				int i=0;
				while(resultSet.next())
				{
					int id=resultSet.getInt("id");
					
					String name=resultSet.getString("name");
		
					String email=resultSet.getString("email");

					String pass=resultSet.getString("password");
					String verified=resultSet.getString("verified");
					
					
					
					ProductOwner pro1=new ProductOwner(id, name, email, pass, verified);
					p[i]=pro1;
					i++;
				}
		      return p;
			} catch (SQLException e) {
				
				e.printStackTrace();
				return null;
			}
			 	 
	 }
     public Customer[] displayAllCustomer() {
			 try {
				ps=connection.prepareStatement(DISPLAYCUSTOMERQUERY);
				
				ResultSet resultSet=ps.executeQuery();
				
				Customer[] p=new Customer[10];
				int i=0;
				while(resultSet.next())
				{
					int id=resultSet.getInt("id");
					
					String name=resultSet.getString("name");
		
					String email=resultSet.getString("email");

					String pass=resultSet.getString("password");
					
					
					
					
					Customer pro1=new Customer(id, name, email, pass);
					p[i]=pro1;
					i++;
				}
		      return p;
			} catch (SQLException e) {
				
				e.printStackTrace();
				return null;
			}	 
	 }
     public int verifyProductOwner(String email,String verified) {
    	try {
			ps=connection.prepareStatement(VERIFYPRODUCTOWNER);
			ps.setString(1, verified);
			ps.setString(2, email);
			
			return ps.executeUpdate();
					
		} catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
     }
     
     public Admin[] displayAllAdmin() {
		 try {
			ps=connection.prepareStatement(DISPLAYADMINQUERY);
			
			ResultSet resultSet=ps.executeQuery();
			
			Admin[] a=new Admin[10];
			int i=0;
			while(resultSet.next())
			{
				int id=resultSet.getInt("id");
				
				String email=resultSet.getString("email");

				String pass=resultSet.getString("password");
				
				
				
				
				Admin adm=new Admin(id, email, pass);
				a[i]=adm;
				i++;
			}
	      return a;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}	 
 }
}
