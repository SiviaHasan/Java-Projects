package com.jspider.product_management_application_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.jspider.product_management_application_connection.DatabaseConnection;

import com.jspider.product_management_application_dto.Product;


public class ProductDao {
	
	
	Connection connection= DatabaseConnection.getConnection();
	 PreparedStatement ps;
	 private final String DISPLAYPRODUCTQUERY="SELECT * from product";
	 private final String DELETEPRODUCTBYID="delete from product where id=?";
	 private final String INSERTPRODUCTQUERY="insert into product(name,color,price,md,expd)values(?,?,?,?,?)";
	 private final String UPDATENAMEOFRODUCTBYID="update product set name=? where id=?";
	 private final String UPDATEEXPDOFRODUCTBYID = "update product set expd=? where id=?";
	 private final String UPDATEMFDOFRODUCTBYID = "update product set md=? where id=?";
	 private final String UPDATEPRICEOFRODUCTBYID ="update product set price=? where id=?";
	 private final String UPDATECOLOROFRODUCTBYID ="update product set color=? where id=?";
	public Product[] displayAllProduct() {
		 try {
			ps=connection.prepareStatement(DISPLAYPRODUCTQUERY);
			
			ResultSet resultSet=ps.executeQuery();
			
			Product[] p=new Product[10];
			int i=0;
			while(resultSet.next())
			{
				int id=resultSet.getInt("id");
				
				String name=resultSet.getString("name");
				double price=resultSet.getDouble("price");
				String color=resultSet.getString("color");
				
				LocalDate md=resultSet.getDate("md").toLocalDate();
				LocalDate expd=resultSet.getDate("expd").toLocalDate();
				
				Product pro1=new Product(id, name, price, color, md, expd);
				p[i]=pro1;
				i++;
			}
	      return p;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
	 }	
	public int deleteProduct(int id) {
		 try {
			ps=connection.prepareStatement(DELETEPRODUCTBYID);
			ps.setInt(1, id);
			
			return ps.executeUpdate();
			
			
			}      
       	catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
	 }	
	public int insertProduct(Product pr) {
		 try {
			ps=connection.prepareStatement(INSERTPRODUCTQUERY);
			
			ps.setString(1, pr.getName());
			ps.setString(2, pr.getColor());
			ps.setDouble(3, pr.getPrice());
			ps.setObject(4, pr.getMd());
			ps.setObject(5, pr.getExpd());
			return ps.executeUpdate();
			
			
			}      
      	catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
	 }	
	public int updateNameById(String name,int id) {
		 try {
			ps=connection.prepareStatement(UPDATENAMEOFRODUCTBYID);
			
			ps.setString(1, name);
			ps.setInt(2, id);
			
			return ps.executeUpdate();
			
			
			}      
     	catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
	 }	
	public int updateColorById(String color,int id) {
		 try {
			ps=connection.prepareStatement(UPDATECOLOROFRODUCTBYID);
			
			ps.setString(1, color);
			ps.setInt(2, id);
			
			return ps.executeUpdate();
			
			
			}      
    	catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
	 }	
	public int updatePriceById(Double price,int id) {
		 try {
			ps=connection.prepareStatement(UPDATEPRICEOFRODUCTBYID);
			
			ps.setDouble(1,price);
			ps.setInt(2, id);
			
			return ps.executeUpdate();
			
			
			}      
   	catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
	 }	
	public int updateMfdById(String md,int id) {
		 try {
			ps=connection.prepareStatement(UPDATEMFDOFRODUCTBYID);
			
			ps.setObject(1, LocalDate.parse(md));
			ps.setInt(2, id);
			
			return ps.executeUpdate();
			
			
			}      
   	catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
	}
	public int updateExpdById(String expd,int id) {
		 try {
			ps=connection.prepareStatement(UPDATEEXPDOFRODUCTBYID);
			
			ps.setObject(1, LocalDate.parse(expd));
			ps.setInt(2, id);
			
			return ps.executeUpdate();
			
			
			}      
  	catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
	}
  }
