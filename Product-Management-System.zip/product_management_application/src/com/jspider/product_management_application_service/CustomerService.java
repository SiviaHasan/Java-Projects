package com.jspider.product_management_application_service;

import com.jspider.product_management_application_dao.CustomerDao;
import com.jspider.product_management_application_dto.Customer;

public class CustomerService {
     CustomerDao dao=new CustomerDao();
     
     public Customer registerCustomerService(Customer c) {
 		if(c.getName().length()<=20) {
 			return dao.customerRegistration(c);
 		}
 		else
 			return null;
 		
 	}
     public int loginCustomerService(String email,String pass) {
  		Customer[] cd=dao.customerLogin();
  		for(Customer customer:cd)
  		{
  			if(customer!=null && customer.getEmail().equalsIgnoreCase(email)) 
  			{
  				if(customer.getPassword().equalsIgnoreCase(pass))
  				      return 1;
  				else
  					return 0;
  			}
  		
  		}
  		return 0;
  		
  	}
}
