package com.jspider.product_management_application_service;


import com.jspider.product_management_application_dao.ProductOwnerDao;
import com.jspider.product_management_application_dto.Customer;
import com.jspider.product_management_application_dto.ProductOwner;

public class ProductOwnerService {
 
	  ProductOwnerDao dao=new ProductOwnerDao();
	     
	     public ProductOwner registerProductOwnerService(ProductOwner po) {
	 		if(po.getName().length()<=20) {
	 			return dao.productOwnerRegistration(po);
	 		}
	 		else
	 			return null;
	 		
	 	}
	     public int loginProductOwnerService(String email,String pass) {
	   		ProductOwner[] productOwner=dao.productOwnerLogin();
	   		for(ProductOwner po:productOwner)
	   		{
	   			if(po!=null && po.getEmail().equalsIgnoreCase(email)) 
	   			{
	   				if(po.getPassword().equalsIgnoreCase(pass)  && po.getVerified().equalsIgnoreCase("yes"))
	   				      return 1;
	   				else
	   					return 0;
	   			}
	   		
	   		}
	   		return -1;
	   		
	   	}
}
