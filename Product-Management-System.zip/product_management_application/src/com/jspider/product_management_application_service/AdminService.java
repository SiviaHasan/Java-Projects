package com.jspider.product_management_application_service;

import com.jspider.product_management_application_dao.AdminDao;
import com.jspider.product_management_application_dto.Admin;
import com.jspider.product_management_application_dto.ProductOwner;

public class AdminService {
   
	AdminDao adao=new AdminDao();
	
	public  void verifyProductOwner(String email,String verified) 
	{
		ProductOwner[] p=adao.displayAllProductOwner();
		for(ProductOwner p1:p)
		{
			if(p1!=null && email.equals(p1.getEmail()))
			{
				if(verified.equals(p1.getVerified())) {
						System.out.println("Already verified product Owner.."); 
						return;
				}
				else {
					    if(adao.verifyProductOwner(email, verified)>0)
					    {
					    	System.out.println("Verified Succesfull");
					    	return;
					    }
					         
					    else
					    	System.out.println("Not verified");
				}
					
			}
			
		}
		System.out.println("email is incorrect"); 
	}
	public  int verifyAdmin(String email,String password) 
	{
		Admin[] a=adao.displayAllAdmin();
		for(Admin a1:a)
		{
			if(a1!=null && email.equals(a1.getEmail()))
			{
				if(password.equalsIgnoreCase(a1.getPassword()))			
					 return 1;
			     
				else 
					return 0;
			}
			
		}
	return 0;
	}
}
