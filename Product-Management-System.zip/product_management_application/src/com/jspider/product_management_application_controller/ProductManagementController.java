package com.jspider.product_management_application_controller;

import java.time.LocalDate;
import java.util.Scanner;

import com.jspider.product_management_application_dao.AdminDao;
import com.jspider.product_management_application_dao.CustomerDao;
import com.jspider.product_management_application_dao.ProductDao;
import com.jspider.product_management_application_dao.ProductOwnerDao;
import com.jspider.product_management_application_dto.Customer;
import com.jspider.product_management_application_dto.Product;
import com.jspider.product_management_application_dto.ProductOwner;
import com.jspider.product_management_application_service.AdminService;
import com.jspider.product_management_application_service.CustomerService;
import com.jspider.product_management_application_service.ProductOwnerService;

public class ProductManagementController {
  public static void main(String[] args) {
	 AdminDao Adao=new AdminDao();
	 AdminService a_service=new AdminService();
	 
	 CustomerDao cDao=new CustomerDao();
	 CustomerService c_service=new CustomerService();
	 
	 ProductOwnerDao pDao=new ProductOwnerDao();
	 ProductOwnerService po_service=new ProductOwnerService();
	 
	 ProductDao productDao=new ProductDao();
	 
	boolean app_start=true;
	Scanner sc=new Scanner(System.in);
	while(app_start) {

		System.out.println("1.Login Admin\n2.Login Customer\n3.Login Product Owner\n4.Register Product owner\n5.Register Customer\n6.Exit the application");
		int option=sc.nextInt();
		sc.nextLine();
		switch(option) {
		case 1:
		  {
			System.out.println("ENter the userName");
			String userName=sc.nextLine();
			System.out.println("Enter the password");
			String pass=sc.nextLine();
			if(a_service.verifyAdmin(userName, pass)==1) {
				System.out.println("Login Successfully");	
				
		    boolean admin_lo=true;
			while(admin_lo)	{
		
				System.out.println("1.VerifyProduct Owner\n2.Display All Product\n3.Display All Customer\n4.Display All ProductOwner\n5.Logout ");
				int aoption=sc.nextInt();
				sc.nextLine();
				switch(aoption)
				{
				 
				 
				 case 1:{
					  
					 System.out.println("Enter the email of productOwner");
					 String email=sc.nextLine();
				      
					a_service.verifyProductOwner(email,"yes" );
					 
		    		}break;
				      case 2:{
					       Product[] p=Adao.displayAllProduct();
					       for(Product p1:p)
					       {
						     if(p1!=null)
							   System.out.println(p1);
						     
						    
					       }
		          		}break;
				      case 3:{
				    	  Customer[] p=Adao.displayAllCustomer();
					       for(Customer p1:p)
					       {
						     if(p1!=null)
							   System.out.println(p1);
						         
					       }
				   		}break;
				      case 4:{
				    	  ProductOwner[] p=Adao.displayAllProductOwner();
					       for(ProductOwner p1:p)
					       {
						     if(p1!=null)
							   System.out.println(p1);
						     
						    
					       }
		         		}break;
				      case 5:{
				    	  System.out.println("Logout Successfully");
				    	  admin_lo=false;
				         }break;
				      default:{
				    	  System.out.println("Enter a valid option");
				      }
				      
				}
			  }	
			}
			else
				System.out.println("Email or password is incorrect");
			
			
		  }
		   break;
		case 2:{
			System.out.println("Enter your email");
			String email=sc.nextLine();
			System.out.println("Enter the password");
			String password=sc.nextLine();
			
			int n=c_service.loginCustomerService(email, password);
			if(n==1) 
			{
				boolean c_login=true;
				
				System.out.println("Customer Login Successfully");
				while(c_login) {
				System.out.println("ENter 1 to Display Product\nEnter 2 to logout");
				int value=sc.nextInt();
				if(value==1)
				{
					Product[] p=productDao.displayAllProduct();
					for(Product ps:p)
						if(ps!=null)
							System.out.println(ps);
				}
				else if(value==2) {
					System.out.println("Logout successfully");
					c_login=false;
				}			
				else
					System.out.println("Enter a valid option");
				}	
					
			}
			else
			{
				System.out.println("Email is not correct");
				System.out.println("password is not correct ");
			}
			
			
		   }break;
		   
		case 3:{
			System.out.println("Enter your email");
			String email=sc.nextLine();
			System.out.println("Enter the password");
			String password=sc.nextLine();
			
			int n=po_service.loginProductOwnerService(email, password);
			if(n==1) 
			{
				boolean b=true;
				System.out.println("ProductOwner Login Successfully");
				while(b==true) {
				   System.out.println("ENter 1 to Display Product\nEnter 2 to delete product\nEnter 3 to update product details\nEnter 4 to insert product\nEnter 5 to logout");
				   int value=sc.nextInt();
				
			    	switch(value) {
				   case 1:{
					 Product[] p=productDao.displayAllProduct();
					 if(p.length==0)
						System.out.println("No products available");
					 for(Product ps:p)
						if(ps!=null)
							System.out.println(ps);

				   }break;
				  case 2:{
					 System.out.println("Enter the product id: ");
					 int p_id=sc.nextInt();
					 if(productDao.deleteProduct(p_id)==1)
						System.out.println("Product deleted successfully ");
					 else
						System.out.println("Not valid product  id");

				    }break;
				    
				case 3:{
					System.out.println("Enter 1 to update name\nEnter 2 to update the color\nEnter 3 to update price\nEnter 4 to update mfd\nEnter 5 to update expdate  ");
					int v=sc.nextInt();
					switch(v) {
					   case 1:{
					   	System.out.println("Enter the product id to update product name: ");
						int p_id=sc.nextInt();
						sc.nextLine();
						System.out.println("Enter the product new name");
					   	String p_name=sc.nextLine();
                        if(productDao.updateNameById(p_name, p_id)==1)
                        	System.out.println("Product name updated Successfully");
                        else
                        	System.out.println("Enter a valid id");
						
					    }break;
					    
					   case 2:{
						   	System.out.println("Enter the product id to update product color: ");
							int p_id=sc.nextInt();
							sc.nextLine();
							System.out.println("Enter the  product new color");
						   	String p_color=sc.nextLine();
	                        if(productDao.updateColorById(p_color, p_id)==1)
	                        	System.out.println("Product color updated Successfully");
	                        else
	                        	System.out.println("Enter a valid id");
							
						    }break;
						    
					   case 3:{
						   	System.out.println("Enter the product id to update product price: ");
							int p_id=sc.nextInt();
	
							System.out.println("Enter the  product new price");
						   	double p_price=sc.nextInt();
	                        if(productDao.updatePriceById(p_price, p_id)==1)
	                        	System.out.println("Product price updated Successfully");
	                        else
	                        	System.out.println("Enter a valid id");
							
						    }break;
						    
					   case 4:{
						   	System.out.println("Enter the product id to update product md: ");
							int p_id=sc.nextInt();
	                        sc.nextLine();
							System.out.println("Enter the product new md");
						   	String p_md=sc.nextLine();
	                        if(productDao.updateMfdById(p_md, p_id)==1)
	                        	System.out.println("Product md updated Successfully");
	                        else
	                        	System.out.println("Enter a valid id");
							
						    }break;
						    
					   case 5:{
						   	System.out.println("Enter the product id to update product expd: ");
							int p_id=sc.nextInt();
	                         
						    sc.nextLine();	
							System.out.println("Enter the product new expd");
						   	String p_expd=sc.nextLine();
	                        if(productDao.updateExpdById(p_expd, p_id)==1)
	                        	System.out.println("Product expd updated Successfully");
	                        else
	                        	System.out.println("Enter a valid id");
							
						    }break;
					  }

				    }break;
				 
				case 4:{
					
					sc.nextLine();
					System.out.println("Enter the product name: ");		
					String p_name=sc.nextLine();
					System.out.println("Enter the product color: ");
					String p_color=sc.nextLine();
					System.out.println("Enter the product price: ");
					double p_id=sc.nextDouble();
					sc.nextLine();
					System.out.println("Enter the product md: ");
					String md=sc.nextLine();
					System.out.println("Enter the product expd: ");
					String expd=sc.nextLine();
					int v=productDao.insertProduct(new Product(p_name, p_id, p_color, LocalDate.parse(md), LocalDate.parse(expd)));

					if(v==1)
						System.out.println("Product inserted successfully");
					else
						System.out.println("Check details");
				    }break;
				case 5:{
					System.out.println("Logout Successfully");
					b=false;
					
				  }break;
			   default:{
					  System.out.println("Enter a valid option");
				  }
				}
				
			  }
			}
			else if(n==-1)
			{
				System.out.println("Email is not correct ");
				
			}
			else
				System.out.println("You are not verified or password is not correct");
				
				
		   }break;
		   
		case 4:{
			System.out.println("Enter your email");
//			sc.nextLine();
			String email=sc.nextLine();
			System.out.println("ENter the Name");
			String name=sc.nextLine();
			System.out.println("Enter the password");
			String password=sc.nextLine();
			
			ProductOwner c=po_service.registerProductOwnerService(new ProductOwner(name, email, password));
			if(c!=null)
				System.out.println("Product Owner Registered Successfully");
			else
			{
				System.out.println("Data is not correct");
				System.out.println("Name should be of 20 length or less ");
			}
			
			
		   }break;
		   
		case 5:{
			System.out.println("Enter your email");
			String email=sc.nextLine();
			System.out.println("ENter the Name");
			String name=sc.nextLine();
			System.out.println("Enter the password");
			String password=sc.nextLine();
			

			Customer c=c_service.registerCustomerService(new Customer(name, email, password));
	
			if(c!=null)
				System.out.println("Registered Successfully");
			else {
				System.out.println("Data is not correct");
				System.out.println("Enter the name of 20 letter or less than ");
			}
				
			
		   }break;
		case 6:{
			System.out.println("Thanks for visiting....");
			app_start=false;
		    }
		}
	}
 }
}
