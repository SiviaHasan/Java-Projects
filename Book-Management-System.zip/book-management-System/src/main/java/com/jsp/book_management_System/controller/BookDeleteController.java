package com.jsp.book_management_System.controller;

import java.io.IOException;

import com.jsp.book_management_System.dao.BookDao;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class BookDeleteController extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		int id=Integer.parseInt(req.getParameter("id"));
		new BookDao().deleteBookById(id);
		
		RequestDispatcher dispatcher=req.getRequestDispatcher("first-page.jsp");
		dispatcher.include(req, res);
		
	}

}
