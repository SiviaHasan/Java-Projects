package com.jsp.book_management_System.controller;

import java.io.IOException;

import com.jsp.book_management_System.dao.BookDao;
import com.jsp.book_management_System.dto.Book;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet (value = "/BookUpdate")
public class BookEditController  extends HttpServlet{

	 @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		 BookDao dao=new BookDao();
		 
		 int id=Integer.parseInt(req.getParameter("id"));
		 String author=req.getParameter("author");
		 String title=req.getParameter("title");
		 Double price=Double.parseDouble(req.getParameter("price"));
		 
		 Book book=new Book(id, title, author, price);
		 
		 dao.updateBook(book);
		 
		 req.getRequestDispatcher("first-page.jsp").forward(req, resp);
		 
		
		 
	}
}
