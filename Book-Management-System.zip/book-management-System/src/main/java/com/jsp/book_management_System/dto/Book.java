package com.jsp.book_management_System.dto;

import java.util.Objects;

public class Book {
   private int id;
   private String title;
   private String author;
   private Double price;
   
   
public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getTitle() {
	return title;
}


public void setTitle(String title) {
	this.title = title;
}


public String getAuthor() {
	return author;
}


public void setAuthor(String author) {
	this.author = author;
}


public Double getPrice() {
	return price;
}


public void setPrice(Double price) {
	this.price = price;
}


@Override
public int hashCode() {
	return Objects.hash(author, id, price, title);
}



public Book(int id, String title, String author, Double price) {
	super();
	this.id = id;
	this.title = title;
	this.author = author;
	this.price = price;
}


@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Book other = (Book) obj;
	return Objects.equals(author, other.author) && id == other.id && Objects.equals(price, other.price)
			&& Objects.equals(title, other.title);
}


@Override
public String toString() {
	return "Book [id=" + id + ", title=" + title + ", author=" + author + ", price=" + price + "]";
}
   
}
