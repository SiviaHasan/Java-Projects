package com.jsp.book_management_System.controller;

import java.io.IOException;
import java.io.PrintWriter;

import com.jsp.book_management_System.dao.BookDao;
import com.jsp.book_management_System.dto.Book;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class BookInsertController implements Servlet{

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		BookDao bookDao=new BookDao();
		
		PrintWriter printWriter=res.getWriter();
	    
		int id=Integer.parseInt(req.getParameter("id"));
		String title=req.getParameter("title");
		String author=req.getParameter("author");
		Double price=Double.parseDouble(req.getParameter("price"));
		
		Book book=new Book(id, title, author, price);
		bookDao.addNewBook(book);
		
		printWriter.write("<html><body>");
		printWriter.write("<h2>Book-Details</h2>");
		printWriter.write("<h4>Book id: "+ id +"</h4>"+"<br> <h4> Book author:"+ author +"</h4><br><h4> Book title: "+ title +"</h4><br><h4> Book price: "+price +"</h4>");
		printWriter.write("</body></html>");
		
		RequestDispatcher dispatcher= req.getRequestDispatcher("first-page.jsp");
		dispatcher.include(req, res);
		
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
    
}
