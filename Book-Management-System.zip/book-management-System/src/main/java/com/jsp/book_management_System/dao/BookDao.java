package com.jsp.book_management_System.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jsp.book_management_System.connection.BookConnection;
import com.jsp.book_management_System.dto.Book;

public class BookDao {
   Connection connection=BookConnection.getConnection();
   PreparedStatement ps;
   private final String ADDNEWBOOK="insert into books(id,title,author,price)values(?,?,?,?)";
   
   
   public Book addNewBook(Book bk) {
	   try {
		ps=connection.prepareStatement(ADDNEWBOOK);
		ps.setInt(1, bk.getId());
		ps.setString(2,bk.getTitle());
		ps.setString(3, bk.getAuthor());
		ps.setDouble(4, bk.getPrice());
		
		ps.execute();
		return bk;
	} catch (SQLException e) {
		
		e.printStackTrace();
		return null;
	}
	  
	   
   }
   public List<Book> displayAllBooksDao(){
	   String DISPLAYALLBOOKS="select  * from books";
	   try {
		ps=connection.prepareStatement(DISPLAYALLBOOKS);
		List<Book> bk=new ArrayList<Book>();
		 ResultSet set= ps.executeQuery();
		 while(set.next())
		 {
			 int id=set.getInt("id");
			 String title=set.getString("title");
			 String author=set.getString("author");
			 Double price=set.getDouble("price");
			 
			 Book book=new Book(id, title, author, price);
			 
			 bk.add(book);
			 
		 }
		 return bk;
	} catch (SQLException e) {
		
		e.printStackTrace();
		return null;
	}
	  
   }
   public int deleteBookById(int id) {
	   String DELETEBYID="delete from books where id=?";
	   try {
		ps=connection.prepareStatement(DELETEBYID);
		ps.setInt(1, id);
		return  ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	}
	  
   }
   public int updateBook(Book book) {
	   String UPDATEBOOK="update books set title=?,author=?,price=? where id=?";
	   try {
		ps=connection.prepareStatement(UPDATEBOOK);
		ps.setString(1,book.getTitle());
		ps.setString(2, book.getAuthor());
		ps.setDouble(3, book.getPrice());
		ps.setInt(4, book.getId());
		
		return ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
		return -1;
	}
	   
   }
   public Book getBookById(int B_id) {
	   String BOOKBYID="select * from books where id=?";
	   try {
		ps=connection.prepareStatement(BOOKBYID);
		  ps.setInt(1, B_id);
		  
		 ResultSet set= ps.executeQuery();
		 Book book=null;
		  
		 if(set.next()) {
			 int id=set.getInt("id");
			 String title=set.getString("title");
			 String author=set.getString("author");
			 Double price=set.getDouble("price");
			 
			book=new Book(id, title, author, price);
		 }
		return book; 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
	 
   }
}
